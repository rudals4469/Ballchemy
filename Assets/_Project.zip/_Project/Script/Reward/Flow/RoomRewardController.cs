using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class RoomRewardController :
    MonoBehaviour
{
    [Header("Room References")]

    [SerializeField]
    private BlockGridManager
        blockGridManager;

    [SerializeField]
    private StageRoomNavigator
        roomNavigator;

    [SerializeField]
    private TurnManager
        turnManager;

    [Header("Reward References")]

    [SerializeField]
    private RoomRewardGenerator
        rewardGenerator;

    [SerializeField]
    private RewardSelectionUI
        rewardSelectionUI;

    [SerializeField]
    private BallCollection
        ballCollection;

    [SerializeField]
    private RunAugmentState
        runAugmentState;

    [SerializeField]
    private RunRewardState
        runRewardState;

    [Header("Debug")]

    [Tooltip(
        "None이면 방 타입에 맞는 정상 보상 등급을 사용합니다.\n" +
        "Tier3로 설정하면 일반 또는 네임드 전투방에서도 " +
        "Tier3 증강 보상을 테스트할 수 있습니다.\n" +
        "테스트 후 반드시 None으로 되돌립니다."
    )]
    [SerializeField]
    private RewardTier
        debugRewardTierOverride =
            RewardTier.None;

    [SerializeField]
    private bool showDebugLog = true;

    private readonly List<RewardDefinition>
        pendingChoices =
            new List<RewardDefinition>();

    private bool isRewardPending;

    public bool IsRewardPending =>
        isRewardPending;

    private void Awake()
    {
        FindReferences();
        ValidateReferences();
    }

    private void OnEnable()
    {
        FindReferences();
        SubscribeEvents();
    }

    private void OnDisable()
    {
        UnsubscribeEvents();
        ReleaseLocksOnDisable();
    }

    private void OnDestroy()
    {
        UnsubscribeEvents();
    }

    private void OnValidate()
    {
        FindReferences();
    }

    private void FindReferences()
    {
        if (blockGridManager == null)
        {
            blockGridManager =
                FindFirstObjectByType<
                    BlockGridManager
                >();
        }

        if (roomNavigator == null)
        {
            roomNavigator =
                FindFirstObjectByType<
                    StageRoomNavigator
                >();
        }

        if (turnManager == null)
        {
            turnManager =
                FindFirstObjectByType<
                    TurnManager
                >();
        }

        if (rewardGenerator == null)
        {
            rewardGenerator =
                FindFirstObjectByType<
                    RoomRewardGenerator
                >();
        }

        if (rewardSelectionUI == null)
        {
            rewardSelectionUI =
                FindFirstObjectByType<
                    RewardSelectionUI
                >(
                    FindObjectsInactive.Include
                );
        }

        if (ballCollection == null)
        {
            ballCollection =
                FindFirstObjectByType<
                    BallCollection
                >();
        }

        if (runAugmentState == null)
        {
            runAugmentState =
                FindFirstObjectByType<
                    RunAugmentState
                >();
        }

        if (runRewardState == null)
        {
            runRewardState =
                FindFirstObjectByType<
                    RunRewardState
                >();
        }
    }

    private void SubscribeEvents()
    {
        if (blockGridManager != null)
        {
            blockGridManager.RoomCleared -=
                HandleRoomCleared;

            blockGridManager.RoomCleared +=
                HandleRoomCleared;
        }

        if (rewardSelectionUI != null)
        {
            rewardSelectionUI.RewardSelected -=
                HandleRewardSelected;

            rewardSelectionUI.RewardSelected +=
                HandleRewardSelected;
        }
    }

    private void UnsubscribeEvents()
    {
        if (blockGridManager != null)
        {
            blockGridManager.RoomCleared -=
                HandleRoomCleared;
        }

        if (rewardSelectionUI != null)
        {
            rewardSelectionUI.RewardSelected -=
                HandleRewardSelected;
        }
    }

    private void HandleRoomCleared()
    {
        if (isRewardPending)
        {
            return;
        }

        if (!CanOpenRoomReward())
        {
            return;
        }

        if (ballCollection == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "BallCollection이 없어 보상 선택지를 " +
                "생성할 수 없습니다.",
                this
            );

            ReleaseRoomAfterReward();

            return;
        }

        RoomNode currentRoom =
            roomNavigator.CurrentRoom;

        RewardTier baseRewardTier =
            ResolveRewardTier(
                currentRoom.RoomType
            );

        if (debugRewardTierOverride !=
            RewardTier.None)
        {
            baseRewardTier =
                debugRewardTierOverride;
        }

        if (baseRewardTier ==
            RewardTier.None)
        {
            if (showDebugLog)
            {
                Debug.Log(
                    "RoomRewardController: " +
                    $"{currentRoom.RoomType} 방은 " +
                    "현재 보상 대상이 아닙니다.",
                    this
                );
            }

            return;
        }

        RewardTier finalRewardTier =
            ResolveFinalRewardTier(
                baseRewardTier
            );

        RewardApplyContext applyContext =
            CreateApplyContext();

        List<RewardDefinition> choices =
            rewardGenerator.GenerateChoices(
                finalRewardTier,
                applyContext
            );

        if (choices == null ||
            choices.Count == 0)
        {
            Debug.LogWarning(
                "RoomRewardController: " +
                $"{currentRoom.RoomType} 방의 " +
                $"{finalRewardTier} 보상 선택지를 " +
                "생성하지 못했습니다.",
                this
            );

            /*
             * 보상 선택지 생성에 실패했으므로
             * 예약된 보상 등급 증가는 소비하지 않습니다.
             */
            ReleaseRoomAfterReward();

            return;
        }

        /*
         * 실제 보상 선택지가 정상 생성된 경우에만
         * 다음 전투방 보상 증가 예약을 소비합니다.
         */
        bool consumedRewardUpgrade =
            ConsumePendingRewardUpgradeIfNeeded();

        pendingChoices.Clear();

        pendingChoices.AddRange(
            choices
        );

        isRewardPending =
            true;

        roomNavigator.SetNavigationLocked(
            true
        );

        turnManager?.SetInputLocked(
            true
        );

        rewardSelectionUI.ShowChoices(
            pendingChoices
        );

        if (showDebugLog)
        {
            Debug.Log(
                "RoomRewardController: " +
                $"Room {currentRoom.RoomId}, " +
                $"{currentRoom.RoomType} 클리어 보상, " +
                $"기본 등급={baseRewardTier}, " +
                $"최종 등급={finalRewardTier}, " +
                $"승급 예약 소비={consumedRewardUpgrade}, " +
                $"선택지={pendingChoices.Count}개",
                this
            );
        }
    }

    private RewardTier ResolveFinalRewardTier(
        RewardTier baseRewardTier)
    {
        if (runRewardState == null ||
            !runRewardState
                .HasPendingRewardUpgrade)
        {
            return baseRewardTier;
        }

        return runRewardState
            .ApplyPendingUpgrade(
                baseRewardTier
            );
    }

    private bool
        ConsumePendingRewardUpgradeIfNeeded()
    {
        if (runRewardState == null ||
            !runRewardState
                .HasPendingRewardUpgrade)
        {
            return false;
        }

        return runRewardState
            .ConsumePendingRewardUpgrade();
    }

    private void HandleRewardSelected(
        RewardDefinition selectedReward)
    {
        if (!isRewardPending ||
            selectedReward == null)
        {
            return;
        }

        if (ballCollection == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "BallCollection이 없어 " +
                "보상을 적용할 수 없습니다.",
                this
            );

            RestorePendingChoices();

            return;
        }

        RewardApplyContext applyContext =
            CreateApplyContext();

        if (!selectedReward.CanApply(
                applyContext
            ))
        {
            Debug.LogWarning(
                "RoomRewardController: " +
                $"{selectedReward.DisplayName} 보상은 " +
                "현재 상태에서 적용할 수 없습니다.",
                this
            );

            RestorePendingChoices();

            return;
        }

        bool applied =
            selectedReward.Apply(
                applyContext
            );

        if (!applied)
        {
            Debug.LogWarning(
                "RoomRewardController: " +
                $"{selectedReward.DisplayName} 보상 " +
                "적용에 실패했습니다.",
                this
            );

            RestorePendingChoices();

            return;
        }

        if (showDebugLog)
        {
            Debug.Log(
                "RoomRewardController: " +
                $"{selectedReward.DisplayName} 보상 적용 완료, " +
                $"현재 공 개수={ballCollection.Count}",
                this
            );
        }

        CompleteRewardSelection();
    }

    private RewardApplyContext CreateApplyContext()
    {
        return new RewardApplyContext(
            ballCollection,
            runAugmentState
        );
    }

    private bool CanOpenRoomReward()
    {
        if (roomNavigator == null ||
            rewardGenerator == null ||
            rewardSelectionUI == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "보상 실행에 필요한 참조가 없습니다.",
                this
            );

            return false;
        }

        RoomNode currentRoom =
            roomNavigator.CurrentRoom;

        if (currentRoom == null ||
            !currentRoom.IsCombatRoom)
        {
            return false;
        }

        return currentRoom.RoomType ==
                   RoomType.NormalCombat ||
               currentRoom.RoomType ==
                   RoomType.NamedCombat;
    }

    private static RewardTier ResolveRewardTier(
        RoomType roomType)
    {
        switch (roomType)
        {
            case RoomType.NormalCombat:
                return RewardTier.Tier1;

            case RoomType.NamedCombat:
                return RewardTier.Tier2;

            case RoomType.Boss:
                return RewardTier.Tier3;

            default:
                return RewardTier.None;
        }
    }

    private void RestorePendingChoices()
    {
        roomNavigator?.SetNavigationLocked(
            true
        );

        turnManager?.SetInputLocked(
            true
        );

        if (pendingChoices.Count > 0 &&
            rewardSelectionUI != null)
        {
            rewardSelectionUI.ShowChoices(
                pendingChoices
            );
        }
    }

    private void CompleteRewardSelection()
    {
        rewardSelectionUI?.Hide();

        pendingChoices.Clear();

        isRewardPending =
            false;

        ReleaseRoomAfterReward();
    }

    private void ReleaseRoomAfterReward()
    {
        turnManager?.SetInputLocked(
            false
        );

        roomNavigator?.SetNavigationLocked(
            false
        );
    }

    private void ReleaseLocksOnDisable()
    {
        if (!isRewardPending)
        {
            return;
        }

        isRewardPending =
            false;

        pendingChoices.Clear();

        turnManager?.SetInputLocked(
            false
        );

        roomNavigator?.SetNavigationLocked(
            false
        );
    }

    private void ValidateReferences()
    {
        if (blockGridManager == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "BlockGridManager가 연결되지 않았습니다.",
                this
            );
        }

        if (roomNavigator == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "StageRoomNavigator가 연결되지 않았습니다.",
                this
            );
        }

        if (turnManager == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "TurnManager가 연결되지 않았습니다.",
                this
            );
        }

        if (rewardGenerator == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "RoomRewardGenerator가 연결되지 않았습니다.",
                this
            );
        }

        if (rewardSelectionUI == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "RewardSelectionUI가 연결되지 않았습니다.",
                this
            );
        }

        if (ballCollection == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "BallCollection이 연결되지 않았습니다.",
                this
            );
        }

        if (runAugmentState == null)
        {
            Debug.LogWarning(
                "RoomRewardController: " +
                "RunAugmentState가 연결되지 않았습니다. " +
                "공 보상은 동작하지만 증강 보상은 " +
                "생성되지 않습니다.",
                this
            );
        }

        if (runRewardState == null)
        {
            Debug.LogError(
                "RoomRewardController: " +
                "RunRewardState가 연결되지 않았습니다. " +
                "다음 전투방 보상 등급 증가 효과가 " +
                "적용되지 않습니다.",
                this
            );
        }
    }
}